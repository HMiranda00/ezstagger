bl_info = {
    "name": "EZ Stagger Offset",
    "author": "EZStagger Team",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "Dope Sheet / Action Editor",
    "description": "Alt-drag to apply staggered per-channel frame offsets to selected keyframes",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}

import bpy
import re
from bpy.types import Operator, AddonPreferences
from bpy.props import BoolProperty, EnumProperty


ADDON_KEYMAP_ITEMS = []


def _parse_bone_name_from_datapath(data_path: str) -> str | None:
    if not data_path:
        return None
    # Matches pose.bones["BoneName"]
    match = re.match(r"pose\\.bones\\[\"([^\"]+)\"\]", data_path)
    if match:
        return match.group(1)
    return None


def _action_owners_map() -> dict:
    """Build a mapping from Action datablocks to owning Objects.

    Note: An Action can theoretically be used by multiple owners. In such cases,
    we keep the first encountered owner per Action.
    """
    owners: dict = {}
    # Prefer objects in the active view layer for performance & relevance
    for obj in bpy.context.view_layer.objects:
        ad = getattr(obj, "animation_data", None)
        if not ad:
            continue
        act = getattr(ad, "action", None)
        if act and act not in owners:
            owners[act] = obj
        # Also consider NLA strips that reference actions
        if getattr(ad, "nla_tracks", None):
            for track in ad.nla_tracks:
                for strip in track.strips:
                    act = getattr(strip, "action", None)
                    if act and act not in owners:
                        owners[act] = obj
    return owners


def _gather_relevant_actions(context):
    """Yield actions relevant to the current Dope Sheet/Action Editor context.

    Priority:
    - If the current Dope Sheet is in Action Editor mode, use the displayed action.
    - Otherwise, collect actions from selected objects' animation_data (active action and NLA strip actions).
    - As a fallback, iterate all actions (may include unused datablocks).
    """
    yielded = set()
    area = context.area
    if area and area.type == 'DOPESHEET_EDITOR':
        space = context.space_data
        if getattr(space, 'mode', 'DOPESHEET') == 'ACTION':
            action = getattr(space, 'action', None)
            if action:
                yielded.add(action)
                yield action

    # Selected objects' actions
    for obj in context.selected_objects or []:
        ad = getattr(obj, 'animation_data', None)
        if not ad:
            continue
        act = getattr(ad, 'action', None)
        if act and act not in yielded:
            yielded.add(act)
            yield act
        if getattr(ad, 'nla_tracks', None):
            for track in ad.nla_tracks:
                for strip in track.strips:
                    act = getattr(strip, 'action', None)
                    if act and act not in yielded:
                        yielded.add(act)
                        yield act

    # Fallback: all actions
    for act in bpy.data.actions:
        if act not in yielded:
            yield act


class EZSTAGGER_Preferences(AddonPreferences):
    bl_idname = __name__

    order_mode: EnumProperty(
        name="Default Order",
        description="Default ordering of channels for the stair offset",
        items=(
            ("OUTLINER", "Outliner-like", "Order by owner name, then bone, then path"),
            ("TIME", "Selection-like (Earliest)", "Order by each channel's earliest selected keyframe time"),
        ),
        default="OUTLINER",
    )

    auto_grouping: BoolProperty(
        name="Auto Grouping (per FCurve vs per Owner)",
        description=(
            "Attempt to auto-detect grouping level: if any F-Curve channel header is selected,"
            " group per F-Curve; otherwise group per Object/Bone"
        ),
        default=True,
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="EZ Stagger Offset")
        layout.prop(self, "order_mode")
        layout.prop(self, "auto_grouping")


class EZSTAGGER_OT_stagger_modal(Operator):
    bl_idname = "anim.ez_stagger_modal"
    bl_label = "EZ Stagger Offset"
    bl_description = "Alt-drag to offset selected keyframes with a stagger by channel"
    bl_options = {"REGISTER", "UNDO", "GRAB_CURSOR", "BLOCKING"}

    invert_grouping: BoolProperty(
        name="Invert Grouping",
        description="If true, swap grouping mode: per owner vs per fcurve",
        default=False,
        options=set(),
    )

    use_time_order: BoolProperty(
        name="Use Time Order",
        description="If true, order channels by earliest selected keyframe time",
        default=False,
        options=set(),
    )

    # Internal runtime state
    _initial_mouse_region_x: int | None = None
    _initial_time: float | None = None
    _owners_by_action: dict | None = None
    _groups: list | None = None
    _group_items: dict | None = None
    _fcurves_to_update: set | None = None

    def invoke(self, context, event):
        # Start only in Dope Sheet editor
        area = context.area
        if not area or area.type != 'DOPESHEET_EDITOR':
            self.report({'WARNING'}, "EZ Stagger works in Dope Sheet / Action Editor")
            return {'CANCELLED'}

        # Modifier toggles at invoke
        self.invert_grouping = event.shift
        self.use_time_order = event.ctrl

        # Capture selection snapshot and prepare groups
        ok = self._prepare_groups(context)
        if not ok:
            self.report({'WARNING'}, "No selected keyframes found")
            return {'CANCELLED'}

        # Setup mouse/time reference
        region = context.region
        v2d = region.view2d
        self._initial_mouse_region_x = event.mouse_region_x
        # Convert region x to time (frames)
        x_view, _ = v2d.region_to_view(event.mouse_region_x, event.mouse_region_y)
        self._initial_time = x_view

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'ESC', 'RIGHTMOUSE'}:
            # Revert
            self._apply_offset(0.0)
            self._flush_updates()
            return {'CANCELLED'}

        if event.type == 'MOUSEMOVE':
            # Compute integer frame delta from initial view x
            region = context.region
            v2d = region.view2d
            x_view, _ = v2d.region_to_view(event.mouse_region_x, event.mouse_region_y)
            delta_frames = round(x_view - (self._initial_time or 0.0))
            self._apply_offset(delta_frames)
            self._flush_updates()
            return {'RUNNING_MODAL'}

        if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'} and event.value == 'RELEASE':
            # Confirm current state
            self._flush_updates()
            return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def _prepare_groups(self, context) -> bool:
        """Scan all selected keyframe points and build grouping structures.

        Stores:
        - _groups: list of channel keys in the computed order
        - _group_items: mapping channel key -> list of KeyframeItem
        - _fcurves_to_update: set of fcurves to call update() on after edits
        - _owners_by_action: mapping Action -> Object owner
        """
        # Snapshot owners mapping
        self._owners_by_action = _action_owners_map()

        # Collect all selected keyframes across relevant Actions/FCurves
        KeyItem = _KeyItem
        selected_items: list[KeyItem] = []

        for act in _gather_relevant_actions(context):
            if not act.fcurves:
                continue
            owner = self._owners_by_action.get(act)
            for fc in act.fcurves:
                # Skip invisible/muted? Keep it simple: operate purely on selection flags
                for kp in fc.keyframe_points:
                    if getattr(kp, "select_control_point", False):
                        selected_items.append(KeyItem(owner, act, fc, kp))

        if not selected_items:
            return False

        # Decide grouping mode
        prefs = _prefs()
        group_per_fcurve = True
        if prefs.auto_grouping:
            # Heuristics:
            # 1) If any F-Curve channel header is selected, use per-fcurve
            any_channel_selected = any(it.fcurve.select for it in selected_items)
            # 2) If any owner has selected keys across multiple distinct F-Curves, use per-fcurve
            owner_to_distinct_channels: dict[tuple, set] = {}
            for it in selected_items:
                owner_key = (it.owner_name, it.bone_name)
                if owner_key not in owner_to_distinct_channels:
                    owner_to_distinct_channels[owner_key] = set()
                owner_to_distinct_channels[owner_key].add((it.data_path, it.array_index))
            multi_channel_selected = any(len(s) > 1 for s in owner_to_distinct_channels.values())

            group_per_fcurve = any_channel_selected or multi_channel_selected
            if self.invert_grouping:
                group_per_fcurve = not group_per_fcurve
        else:
            # Default to per-fcurve unless inverted
            group_per_fcurve = not self.invert_grouping

        # Group items
        group_items: dict = {}
        fcurves_to_update: set = set()

        for it in selected_items:
            fcurves_to_update.add(it.fcurve)
            chan_key = it.channel_key_per_fcurve() if group_per_fcurve else it.channel_key_per_owner()
            if chan_key not in group_items:
                group_items[chan_key] = []
            group_items[chan_key].append(it)

        # Determine ordering of channels
        order_mode = self._resolve_order_mode()
        if order_mode == 'TIME':
            # Earliest selected key per channel
            def earliest_time(items: list[KeyItem]) -> float:
                return min(k.orig_co_x for k in items)
            groups_sorted = sorted(group_items.keys(), key=lambda k: earliest_time(group_items[k]))
        else:
            # Outliner-like: owner name, bone name, datapath, array_index
            def outliner_key(k):
                owner_name, bone_name, data_path, array_index = k
                return (
                    owner_name or "",
                    bone_name or "",
                    data_path or "",
                    array_index if array_index is not None else -1,
                )
            groups_sorted = sorted(group_items.keys(), key=outliner_key)

        self._groups = groups_sorted
        self._group_items = group_items
        self._fcurves_to_update = fcurves_to_update
        return True

    def _resolve_order_mode(self) -> str:
        prefs = _prefs()
        if self.use_time_order:
            # Ctrl toggles to TIME ordering during this run
            return 'TIME'
        return prefs.order_mode

    def _apply_offset(self, delta_frames: float) -> None:
        """Apply staggered offsets based on current delta_frames.

        The first group (anchor) gets 0 offset, second gets 1*delta, etc.
        """
        if not self._groups or not self._group_items:
            return
        for idx, gkey in enumerate(self._groups):
            group_offset = idx * delta_frames
            items = self._group_items[gkey]
            for it in items:
                it.apply_offset(group_offset)

    def _flush_updates(self) -> None:
        if not self._fcurves_to_update:
            return
        for fc in self._fcurves_to_update:
            try:
                fc.update()
            except Exception:
                pass


class _KeyItem:
    """Snapshot of a selected keyframe point with minimal context and original values."""

    def __init__(self, owner_obj, action, fcurve, keyframe_point):
        self.owner_obj = owner_obj  # may be None
        self.action = action
        self.fcurve = fcurve
        self.kp = keyframe_point

        # Original coordinates for restore and incremental updates
        self.orig_co_x = float(keyframe_point.co.x)
        self.orig_co_y = float(keyframe_point.co.y)
        self.orig_hl_x = float(keyframe_point.handle_left.x)
        self.orig_hl_y = float(keyframe_point.handle_left.y)
        self.orig_hr_x = float(keyframe_point.handle_right.x)
        self.orig_hr_y = float(keyframe_point.handle_right.y)

        # Pre-parse bone name and details for grouping keys
        self.data_path = fcurve.data_path
        self.array_index = fcurve.array_index
        self.bone_name = _parse_bone_name_from_datapath(self.data_path)
        self.owner_name = getattr(owner_obj, "name", None)

    def channel_key_per_fcurve(self):
        return (self.owner_name, self.bone_name, self.data_path, self.array_index)

    def channel_key_per_owner(self):
        # Collapse datapath dimension; treat owner+bone as the channel
        return (self.owner_name, self.bone_name, None, None)

    def apply_offset(self, offset_x: float):
        new_x = self.orig_co_x + offset_x
        dx = new_x - self.kp.co.x
        # Set control point
        self.kp.co.x = new_x
        # Shift handles horizontally by the same absolute delta from original
        # Keep vertical values unchanged
        self.kp.handle_left.x = self.orig_hl_x + offset_x
        self.kp.handle_right.x = self.orig_hr_x + offset_x


def _prefs() -> EZSTAGGER_Preferences:
    addon_prefs = bpy.context.preferences.addons.get(__name__)
    if addon_prefs is None:
        # Fallback with defaults
        return EZSTAGGER_Preferences()
    return addon_prefs.preferences


classes = (
    EZSTAGGER_Preferences,
    EZSTAGGER_OT_stagger_modal,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    # Keymap: Dope Sheet editor, Alt+LeftMouse (Press) starts modal operator
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="Dopesheet", space_type='DOPESHEET_EDITOR')
        kmi = km.keymap_items.new(EZSTAGGER_OT_stagger_modal.bl_idname, type='LEFTMOUSE', value='PRESS', alt=True)
        ADDON_KEYMAP_ITEMS.append((km, kmi))


def unregister():
    # Remove keymaps
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        for km, kmi in ADDON_KEYMAP_ITEMS:
            try:
                km.keymap_items.remove(kmi)
            except Exception:
                pass
        ADDON_KEYMAP_ITEMS.clear()

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()


